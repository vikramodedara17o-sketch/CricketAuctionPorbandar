# Cricket Auction Porbandar Demo
Android demo prototype with:
- package selection and requested prices
- teams and purses
- player list
- live-auction style screen
- bid button
- SOLD / UNSOLD
- next player
This is a UI/demo build, not yet a production APK. Real multi-device live bidding requires Firebase/backend; real payments require a merchant gateway and secure server verification.
