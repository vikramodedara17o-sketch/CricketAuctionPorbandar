plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}
android {
    namespace="com.porbandar.cricketauction"
    compileSdk=35
    defaultConfig {
        applicationId="com.porbandar.cricketauction"
        minSdk=24
        targetSdk=35
        versionCode=2
        versionName="0.2-demo"
    }
}
dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.12.01"))
    implementation("androidx.activity:activity-compose:1.10.0")
    implementation("androidx.compose.material3:material3")
}
