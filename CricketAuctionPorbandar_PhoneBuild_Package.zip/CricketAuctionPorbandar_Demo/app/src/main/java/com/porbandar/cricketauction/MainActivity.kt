package com.porbandar.cricketauction

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

data class Team(val name:String,var purse:Int)
data class Player(val name:String,val role:String,val base:Int)

val demoTeams=mutableStateListOf(
 Team("Porbandar Kings",100000),Team("Coastal Warriors",100000),
 Team("Royal XI",100000),Team("Sea Hawks",100000),
 Team("Lions CC",100000),Team("Ocean Strikers",100000)
)
val demoPlayers=listOf(
 Player("Rahul Patel","All Rounder",25000),
 Player("Amit Jadeja","Batsman",10000),
 Player("Vivek Solanki","Bowler",15000),
 Player("Karan Makwana","Wicket Keeper",20000)
)

class MainActivity:ComponentActivity(){
 override fun onCreate(b:Bundle?){super.onCreate(b);setContent{App()}}
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun App(){
 var page by remember{mutableStateOf("home")}
 var playerIndex by remember{mutableIntStateOf(0)}
 var bid by remember{mutableIntStateOf(demoPlayers[0].base)}
 var leader by remember{mutableStateOf("No bid")}
 var sold by remember{mutableStateOf(false)}
 var selectedTeam by remember{mutableStateOf(0)}
 var selectedPackage by remember{mutableIntStateOf(6)}
 val prices=mapOf(3 to 499.50,4 to 999.50,6 to 1249.50,8 to 1499.50,12 to 1999.50,16 to 2499.50,20 to 2999.50,30 to 3499.50)
 Scaffold(topBar={TopAppBar(title={Text("🏏 Cricket Auction Porbandar",fontWeight=FontWeight.Bold)})},
 bottomBar={NavigationBar{
  listOf("home" to "Home","auction" to "🔴 Live","teams" to "Teams","players" to "Players").forEach{(id,label)->
   NavigationBarItem(selected=page==id,onClick={page=id},icon={},label={Text(label)})
  }
 }}){pad->
  Column(Modifier.padding(pad).padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
   when(page){
    "home"->{
     Text("Create Auction",style=MaterialTheme.typography.headlineSmall)
     Text("Teams package select karo.")
     prices.forEach{(n,p)->Card(onClick={selectedPackage=n},Modifier.fillMaxWidth()){
      Row(Modifier.padding(14.dp).fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){
       Text("$n Teams",fontWeight=FontWeight.Bold);Text("₹%.2f".format(p))
      }}}
     Button(onClick={page="auction"},Modifier.fillMaxWidth()){Text("Create Demo Auction")}
     Text("Demo mode: payment gateway abhi connected nahi hai.")
    }
    "auction"->{
     val pl=demoPlayers[playerIndex]
     Text("🔴 LIVE AUCTION",style=MaterialTheme.typography.headlineSmall)
     Text(pl.name,fontWeight=FontWeight.Bold,style=MaterialTheme.typography.headlineMedium)
     Text("${pl.role} • Base ₹${pl.base}")
     Text("CURRENT BID",style=MaterialTheme.typography.labelLarge)
     Text("₹$bid",style=MaterialTheme.typography.displaySmall)
     Text("Highest: $leader")
     if(sold) Text("🔨 SOLD",style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Bold)
     Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){
      Button(enabled=!sold,onClick={bid+=5000;leader=demoTeams[selectedTeam].name}){Text("Bid +₹5,000")}
      OutlinedButton(enabled=!sold,onClick={sold=true}){Text("SOLD")}
     }
     OutlinedButton(enabled=!sold,onClick={sold=true;leader="UNSOLD"}){Text("UNSOLD")}
     Text("Teams / purse")
     demoTeams.forEachIndexed{i,t->Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){
      Text("${t.name}");Text("₹${t.purse}")
     }}
     Button(onClick={
      if(playerIndex<demoPlayers.lastIndex){playerIndex++;bid=demoPlayers[playerIndex].base;leader="No bid";sold=false}
     },enabled=playerIndex<demoPlayers.lastIndex,Modifier.fillMaxWidth()){Text("Next Player")}
    }
    "teams"->{
     Text("Teams",style=MaterialTheme.typography.headlineSmall)
     demoTeams.forEachIndexed{i,t->Card(Modifier.fillMaxWidth(),onClick={selectedTeam=i}){
      Row(Modifier.padding(14.dp).fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){
       Text(t.name,fontWeight=if(i==selectedTeam)FontWeight.Bold else FontWeight.Normal);Text("₹${t.purse}")
      }}}
    }
    "players"->{
     Text("Players",style=MaterialTheme.typography.headlineSmall)
     demoPlayers.forEach{p->Card(Modifier.fillMaxWidth()){Column(Modifier.padding(14.dp)){
      Text(p.name,fontWeight=FontWeight.Bold);Text("${p.role} • Base ₹${p.base}")
     }}}
    }
   }
  }
 }
}
