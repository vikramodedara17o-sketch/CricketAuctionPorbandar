package com.porbandar.cricketauction;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity {
    private final ArrayList<Team> teams = new ArrayList<>();
    private final ArrayList<Player> players = new ArrayList<>();
    private int selectedTeam = 0;
    private int playerIndex = 0;
    private int currentBid = 0;
    private String highestBidder = "No bid";
    private boolean sold = false;
    private int selectedPackage = 6;
    private LinearLayout content;

    private static final int BLUE = Color.rgb(13, 71, 161);
    private static final int GREEN = Color.rgb(46, 125, 50);
    private static final int RED = Color.rgb(198, 40, 40);
    private static final int BG = Color.rgb(245, 247, 250);

    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);
        seedData();
        showHome();
    }

    private void seedData() {
        if (!teams.isEmpty()) return;
        String[] names = {"Porbandar Kings", "Coastal Warriors", "Royal XI", "Sea Hawks", "Lions CC", "Ocean Strikers"};
        for (String name : names) teams.add(new Team(name, 100000));
        players.add(new Player("Rahul Patel", "All Rounder", 25000));
        players.add(new Player("Amit Jadeja", "Batsman", 10000));
        players.add(new Player("Vivek Solanki", "Bowler", 15000));
        players.add(new Player("Karan Makwana", "Wicket Keeper", 20000));
    }

    private void baseScreen(String title) {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);

        TextView bar = new TextView(this);
        bar.setText("🏏  " + title);
        bar.setTextColor(Color.WHITE);
        bar.setTextSize(20);
        bar.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(18), dp(8), dp(18), dp(8));
        bar.setBackgroundColor(BLUE);
        root.addView(bar, new LinearLayout.LayoutParams(-1, dp(58)));

        ScrollView scroll = new ScrollView(this);
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(16), dp(16), dp(16), dp(90));
        scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        LinearLayout nav = new LinearLayout(this);
        nav.setGravity(Gravity.CENTER);
        nav.setBackgroundColor(Color.WHITE);
        String[] labels = {"Home", "Live Auction", "Teams", "Players"};
        View.OnClickListener[] actions = {
                v -> showHome(), v -> showAuction(), v -> showTeams(), v -> showPlayers()
        };
        for (int i = 0; i < labels.length; i++) {
            Button b = new Button(this);
            b.setText(labels[i]);
            b.setTextSize(11);
            b.setAllCaps(false);
            b.setOnClickListener(actions[i]);
            nav.addView(b, new LinearLayout.LayoutParams(0, dp(58), 1));
        }
        root.addView(nav);
        setContentView(root);
    }

    private void showHome() {
        baseScreen("Cricket Auction Porbandar");
        addTitle("Create Auction");
        addText("Team package select karo. Demo auction offline mode mein chalega.");
        int[] counts = {3,4,6,8,12,16,20,30};
        double[] prices = {499.50,999.50,1249.50,1499.50,1999.50,2499.50,2999.50,3499.50};
        for (int i = 0; i < counts.length; i++) {
            final int c = counts[i]; final double p = prices[i];
            Button b = new Button(this);
            b.setText(c + " Teams     ₹" + String.format(Locale.US, "%.2f", p) + (c == selectedPackage ? "  ✓" : ""));
            b.setAllCaps(false);
            b.setOnClickListener(v -> { selectedPackage = c; showHome(); });
            content.addView(b, marginParams());
        }
        Button create = button("Create Demo Auction", BLUE);
        create.setOnClickListener(v -> { playerIndex = 0; resetPlayer(); showAuction(); });
        content.addView(create, marginParams());
        addText("Payment gateway is not connected in this APK. Real payment verification should be added on a secure server before production use.");
    }

    private void showAuction() {
        baseScreen("🔴 LIVE AUCTION");
        Player p = players.get(playerIndex);
        if (currentBid == 0) currentBid = p.base;
        addTitle(p.name);
        addText(p.role + "  •  Base Price ₹" + p.base);
        TextView bid = addTitle("CURRENT BID  ₹" + currentBid);
        if (sold) {
            bid.setTextColor(GREEN);
            addTitle("🔨 SOLD");
            addText("Winner: " + highestBidder);
        } else {
            addText("Highest Bidder: " + highestBidder);
            Button bidButton = button("Bid +₹500", BLUE);
            bidButton.setOnClickListener(v -> {
                currentBid += 500;
                highestBidder = teams.get(selectedTeam).name;
                showAuction();
            });
            content.addView(bidButton, marginParams());

            Button bid1k = button("Bid +₹1,000", BLUE);
            bid1k.setOnClickListener(v -> {
                currentBid += 1000;
                highestBidder = teams.get(selectedTeam).name;
                showAuction();
            });
            content.addView(bid1k, marginParams());

            Button soldButton = button("SOLD", GREEN);
            soldButton.setOnClickListener(v -> sellPlayer());
            content.addView(soldButton, marginParams());

            Button unsoldButton = button("UNSOLD", RED);
            unsoldButton.setOnClickListener(v -> { highestBidder = "UNSOLD"; sold = true; showAuction(); });
            content.addView(unsoldButton, marginParams());
        }

        addTitle("Teams / Purse");
        for (int i = 0; i < teams.size(); i++) {
            final int index = i;
            Button t = button(teams.get(i).name + "    ₹" + teams.get(i).purse + (i == selectedTeam ? "  ✓" : ""), Color.DKGRAY);
            t.setOnClickListener(v -> { selectedTeam = index; showAuction(); });
            content.addView(t, marginParams());
        }
        if (playerIndex < players.size() - 1) {
            Button next = button("Next Player →", BLUE);
            next.setOnClickListener(v -> { playerIndex++; resetPlayer(); showAuction(); });
            content.addView(next, marginParams());
        } else {
            Button done = button("Auction Complete", GREEN);
            done.setOnClickListener(v -> Toast.makeText(this, "Demo auction complete", Toast.LENGTH_SHORT).show());
            content.addView(done, marginParams());
        }
    }

    private void sellPlayer() {
        if (sold || highestBidder.equals("No bid")) return;
        Team winner = teams.get(selectedTeam);
        if (winner.purse < currentBid) {
            Toast.makeText(this, "Insufficient purse", Toast.LENGTH_SHORT).show();
            return;
        }
        winner.purse -= currentBid;
        sold = true;
        Toast.makeText(this, "SOLD to " + winner.name, Toast.LENGTH_SHORT).show();
        showAuction();
    }

    private void resetPlayer() {
        currentBid = players.get(playerIndex).base;
        highestBidder = "No bid";
        sold = false;
    }

    private void showTeams() {
        baseScreen("Teams");
        addTitle("Team Purse");
        for (Team t : teams) {
            addText(t.name + "  —  ₹" + t.purse);
        }
    }

    private void showPlayers() {
        baseScreen("Players");
        addTitle("Player List");
        for (Player p : players) addText(p.name + "  •  " + p.role + "  •  Base ₹" + p.base);
    }

    private TextView addTitle(String text) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextSize(22);
        v.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        v.setTextColor(Color.rgb(25, 35, 50));
        v.setPadding(0, dp(8), 0, dp(8));
        content.addView(v, marginParams());
        return v;
    }

    private TextView addText(String text) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextSize(16);
        v.setTextColor(Color.DKGRAY);
        v.setPadding(dp(4), dp(8), dp(4), dp(8));
        content.addView(v, marginParams());
        return v;
    }

    private Button button(String text, int color) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextColor(Color.WHITE);
        b.setTextSize(15);
        b.setAllCaps(false);
        b.setBackgroundColor(color);
        return b;
    }

    private LinearLayout.LayoutParams marginParams() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.setMargins(0, dp(5), 0, dp(5));
        return p;
    }

    private int dp(int value) { return (int)(value * getResources().getDisplayMetrics().density + 0.5f); }

    static class Team {
        String name; int purse;
        Team(String n, int p) { name = n; purse = p; }
    }

    static class Player {
        String name, role; int base;
        Player(String n, String r, int b) { name = n; role = r; base = b; }
    }
}
