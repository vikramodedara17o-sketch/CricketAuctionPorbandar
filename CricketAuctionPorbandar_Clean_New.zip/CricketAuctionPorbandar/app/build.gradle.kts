plugins {
    id("com.android.application")
}

android {
    namespace = "com.porbandar.cricketauction"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.porbandar.cricketauction"
        minSdk = 24
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
